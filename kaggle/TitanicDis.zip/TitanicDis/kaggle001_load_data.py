import pandas as pd
import numpy as np

# 데이터 불러오기
train = pd.read_csv('c:/titanic/train.csv')
test = pd.read_csv('c:/titanic/test.csv')

# train.head()